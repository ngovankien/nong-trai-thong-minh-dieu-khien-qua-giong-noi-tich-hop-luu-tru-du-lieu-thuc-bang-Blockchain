SERIAL_PORT = "COM5"
BAUD_RATE = 9600

BLOCKCHAIN_FILE = "blockchain.json"
HISTORY_FILE = "sensor_history.json"

CAMERA_URL = "http://192.168.7.2:81/stream"
# neu stream khong on dinh thi doi thanh:
# CAMERA_URL = "http://192.168.7.2/capture"
