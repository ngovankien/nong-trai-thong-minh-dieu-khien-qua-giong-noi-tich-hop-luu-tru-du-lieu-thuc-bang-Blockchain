import os
import json
import time
from config import HISTORY_FILE


def load_history():
    if not os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)
        return []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_history(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)


def add_history_point(latest_data):
    history = load_history()
    point = {
        "timestamp": time.time(),
        "temp": latest_data.get("temp"),
        "hum": latest_data.get("hum"),
        "soil": latest_data.get("soil"),
        "flow": latest_data.get("flow"),
        "cycle_ml": latest_data.get("cycle_ml"),
        "total_ml": latest_data.get("total_ml"),
        "pump": latest_data.get("pump"),
        "auto_threshold": latest_data.get("auto_threshold", "OFF"),
        "soil_dry_alert": latest_data.get("soil_dry_alert", "OFF"),
        "no_water_alert": latest_data.get("no_water_alert", "OFF"),
    }
    history.append(point)
    history = history[-500:]
    save_history(history)
