import speech_recognition as sr


def recognize_voice_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Dang nghe...")
        audio = recognizer.listen(source, phrase_time_limit=5)
    try:
        text = recognizer.recognize_google(audio, language="vi-VN").lower()
        return text
    except Exception:
        return ""
