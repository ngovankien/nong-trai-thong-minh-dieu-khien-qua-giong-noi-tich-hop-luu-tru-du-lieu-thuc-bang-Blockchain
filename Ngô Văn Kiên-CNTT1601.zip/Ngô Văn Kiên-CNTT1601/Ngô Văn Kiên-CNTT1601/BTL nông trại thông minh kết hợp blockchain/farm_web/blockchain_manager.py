import os
import json
import time
import hashlib
from datetime import datetime
from config import BLOCKCHAIN_FILE


def calculate_hash(index, timestamp, data, previous_hash):
    raw = f"{index}{timestamp}{json.dumps(data, ensure_ascii=False, sort_keys=True)}{previous_hash}"
    return hashlib.sha256(raw.encode()).hexdigest()


def current_datetime_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def normalize_sensor_data(data):
    normalized = {
        "event": data.get("event", "UNKNOWN"),
        "temp": data.get("temp"),
        "hum": data.get("hum"),
        "soil": data.get("soil"),
        "pump": data.get("pump"),
        "flow": data.get("flow"),
        "cycle_ml": data.get("cycle_ml"),
        "total_ml": data.get("total_ml"),
        "auto_threshold": data.get("auto_threshold"),
        "soil_dry_alert": data.get("soil_dry_alert"),
        "no_water_alert": data.get("no_water_alert"),
        "command": data.get("command"),
        "voice_text": data.get("voice_text"),
        "action": data.get("action"),
        "response": data.get("response"),
        "raw": data.get("raw"),
        "delivered_ml": data.get("delivered_ml"),
        "note": data.get("note"),
    }
    for k, v in data.items():
        if k not in normalized:
            normalized[k] = v
    return normalized


def create_genesis_block():
    now = time.time()
    block = {
        "index": 0,
        "timestamp": now,
        "datetime": current_datetime_str(),
        "data": {
            "event": "GENESIS",
            "note": "Khoi tao chuoi blockchain cho he thong trang trai thong minh"
        },
        "previous_hash": "0"
    }
    block["hash"] = calculate_hash(
        block["index"],
        block["timestamp"],
        block["data"],
        block["previous_hash"]
    )
    return block


def load_blockchain():
    if not os.path.exists(BLOCKCHAIN_FILE):
        chain = [create_genesis_block()]
        save_blockchain(chain)
        return chain
    with open(BLOCKCHAIN_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_blockchain(chain):
    with open(BLOCKCHAIN_FILE, "w", encoding="utf-8") as f:
        json.dump(chain, f, ensure_ascii=False, indent=2)


def add_block(data):
    chain = load_blockchain()
    last_block = chain[-1]
    now = time.time()
    normalized_data = normalize_sensor_data(data)

    new_block = {
        "index": last_block["index"] + 1,
        "timestamp": now,
        "datetime": current_datetime_str(),
        "data": normalized_data,
        "previous_hash": last_block["hash"]
    }

    new_block["hash"] = calculate_hash(
        new_block["index"],
        new_block["timestamp"],
        new_block["data"],
        new_block["previous_hash"]
    )

    chain.append(new_block)
    save_blockchain(chain)
    return new_block


def is_chain_valid():
    chain = load_blockchain()
    for i in range(1, len(chain)):
        current = chain[i]
        previous = chain[i - 1]
        if current["previous_hash"] != previous["hash"]:
            return False
        recalculated = calculate_hash(
            current["index"],
            current["timestamp"],
            current["data"],
            current["previous_hash"]
        )
        if current["hash"] != recalculated:
            return False
    return True
