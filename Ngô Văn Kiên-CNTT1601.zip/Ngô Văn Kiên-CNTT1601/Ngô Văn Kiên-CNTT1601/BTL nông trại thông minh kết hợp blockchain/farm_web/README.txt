py_compile app.py: OK
