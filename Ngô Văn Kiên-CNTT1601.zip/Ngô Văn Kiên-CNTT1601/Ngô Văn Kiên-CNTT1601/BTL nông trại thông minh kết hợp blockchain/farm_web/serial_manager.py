import time
import threading
import serial
from config import SERIAL_PORT, BAUD_RATE

ser = None
serial_lock = threading.Lock()

latest_data = {
    "temp": "--",
    "hum": "--",
    "soil": "--",
    "pump": "OFF",
    "flow": "0",
    "cycle_ml": "0",
    "total_ml": "0",
    "auto_threshold": "OFF",
    "soil_dry_alert": "OFF",
    "no_water_alert": "OFF",
}


def connect_serial():
    global ser
    try:
        if ser is None or not ser.is_open:
            ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=2)
            time.sleep(2)
            print(f"Da ket noi Arduino qua {SERIAL_PORT}")
    except Exception as e:
        print(f"Khong mo duoc cong {SERIAL_PORT}: {e}")
        ser = None


def parse_sensor_line(line: str):
    global latest_data
    try:
        parts = line.strip().split(",")
        parsed = {}
        for part in parts:
            if ":" in part:
                key, value = part.split(":", 1)
                parsed[key] = value

        latest_data["temp"] = parsed.get("TEMP", latest_data["temp"])
        latest_data["hum"] = parsed.get("HUM", latest_data["hum"])
        latest_data["soil"] = parsed.get("SOIL", latest_data["soil"])
        latest_data["pump"] = parsed.get("PUMP", latest_data["pump"])
        latest_data["flow"] = parsed.get("FLOW", latest_data["flow"])
        latest_data["cycle_ml"] = parsed.get("CYCLE_ML", latest_data["cycle_ml"])
        latest_data["total_ml"] = parsed.get("TOTAL_ML", latest_data["total_ml"])
        latest_data["auto_threshold"] = parsed.get("AUTO_THRESHOLD", latest_data["auto_threshold"])
        latest_data["soil_dry_alert"] = parsed.get("SOIL_DRY_ALERT", latest_data["soil_dry_alert"])
        latest_data["no_water_alert"] = parsed.get("NO_WATER_ALERT", latest_data["no_water_alert"])
    except Exception as e:
        print("Loi parse_sensor_line:", e)


def send_serial(cmd: str, wait=1.0):
    global ser
    with serial_lock:
        try:
            if ser is None or not ser.is_open:
                connect_serial()
            if ser is None:
                return [f"ERR:Khong ket noi duoc {SERIAL_PORT}"]
            ser.reset_input_buffer()
            ser.write((cmd + "\n").encode())
            time.sleep(wait)
            lines = []
            while ser.in_waiting:
                line = ser.readline().decode(errors="ignore").strip()
                if line:
                    lines.append(line)
            return lines if lines else ["OK:NO_RESPONSE"]
        except Exception as e:
            print("Loi Serial:", e)
            return [f"ERR:{str(e)}"]


def refresh_sensor_data():
    lines = send_serial("READ_ALL", wait=1.0)
    for line in lines:
        if line.startswith("TEMP:"):
            parse_sensor_line(line)
    return lines
