
from __future__ import annotations

import json
import hashlib
import io
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import requests
import cv2
from flask import Flask, jsonify, render_template, request, send_file, Response

ESP_IP = os.getenv("ESP_IP", "192.168.7.85")
ESP_BASE = f"http://{ESP_IP}"
REQUEST_TIMEOUT = 5

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data_store"
DATA_DIR.mkdir(exist_ok=True)

HISTORY_FILE = DATA_DIR / "history.json"
BLOCKCHAIN_FILE = DATA_DIR / "blockchain.json"

app = Flask(__name__, template_folder="templates", static_folder="static")

# =========================================================
# WEBCAM USB
# =========================================================
CAMERA_INDEX = int(os.getenv("CAMERA_INDEX", "0"))
camera = None


def _open_camera(index: int):
    """
    Ưu tiên DirectShow trên Windows để tránh lỗi MSMF:
    CvCapture_MSMF::grabFrame can't grab frame
    """
    backends = [cv2.CAP_DSHOW, cv2.CAP_ANY]

    for backend in backends:
        try:
            cam = cv2.VideoCapture(index, backend)
        except TypeError:
            cam = cv2.VideoCapture(index)

        if cam is None:
            continue

        cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        cam.set(cv2.CAP_PROP_FPS, 30)

        if cam.isOpened():
            ok, _ = cam.read()
            if ok:
                print(f"[CAMERA] Opened camera index={index} backend={backend}")
                return cam

        cam.release()

    return None


def get_camera():
    global camera
    if camera is None:
        camera = _open_camera(CAMERA_INDEX)
    return camera


def generate_camera_frames():
    global camera

    while True:
        cam = get_camera()

        if cam is None:
            # Tạo khung ảnh báo lỗi thay vì spam warning
            error_frame = 255 * __import__("numpy").ones((480, 800, 3), dtype="uint8")
            cv2.putText(
                error_frame,
                f"Khong mo duoc webcam USB. Thu doi CAMERA_INDEX (hien tai: {CAMERA_INDEX})",
                (20, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                error_frame,
                "Dong Zoom / Camera / Teams / Chrome dang dung webcam roi chay lai.",
                (20, 180),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (50, 50, 50),
                2,
                cv2.LINE_AA,
            )
            ok, buffer = cv2.imencode(".jpg", error_frame)
            if ok:
                frame_bytes = buffer.tobytes()
                yield (
                    b"--frame\r\n"
                    b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
                )
            continue

        ok, frame = cam.read()
        if not ok:
            print("[CAMERA] Mat frame, dang mo lai webcam...")
            try:
                cam.release()
            except Exception:
                pass
            camera = None
            continue

        cv2.putText(
            frame,
            "Smart Farm Live Camera",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 255, 0),
            2,
            cv2.LINE_AA,
        )

        ok, buffer = cv2.imencode(".jpg", frame)
        if not ok:
            continue

        frame_bytes = buffer.tobytes()
        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
        )


def _read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_history() -> List[Dict[str, Any]]:
    return _read_json(HISTORY_FILE, [])


def save_history(items: List[Dict[str, Any]]) -> None:
    _write_json(HISTORY_FILE, items)


def load_blockchain() -> List[Dict[str, Any]]:
    return _read_json(BLOCKCHAIN_FILE, [])


def save_blockchain(items: List[Dict[str, Any]]) -> None:
    _write_json(BLOCKCHAIN_FILE, items)


def calc_hash(block: Dict[str, Any]) -> str:
    raw = json.dumps(
        {
            "index": block["index"],
            "timestamp": block["timestamp"],
            "data": block["data"],
            "prev_hash": block["prev_hash"],
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def ensure_genesis_block() -> None:
    chain = load_blockchain()
    if chain:
        return
    genesis = {
        "index": 0,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": {"event": "GENESIS"},
        "prev_hash": "0",
    }
    genesis["hash"] = calc_hash(genesis)
    save_blockchain([genesis])


def add_block(data: Dict[str, Any]) -> Dict[str, Any]:
    ensure_genesis_block()
    chain = load_blockchain()
    prev = chain[-1]
    block = {
        "index": len(chain),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": data,
        "prev_hash": prev["hash"],
    }
    block["hash"] = calc_hash(block)
    chain.append(block)
    save_blockchain(chain)
    return block


def validate_chain(chain: List[Dict[str, Any]]) -> bool:
    if not chain:
        return True
    for i, block in enumerate(chain):
        if calc_hash(block) != block.get("hash"):
            return False
        if i == 0:
            if block.get("prev_hash") != "0":
                return False
        else:
            if block.get("prev_hash") != chain[i - 1].get("hash"):
                return False
    return True


def get_esp_data() -> Dict[str, Any]:
    try:
        r = requests.get(f"{ESP_BASE}/data", timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {
            "temp": "--",
            "hum": "--",
            "soil": "--",
            "soil_percent": "--",
            "pump": "OFF",
            "flow": "0.00",
            "cycle_ml": "0.00",
            "total_ml": "0.00",
            "auto_threshold": "OFF",
            "soil_dry_alert": "OFF",
            "no_water_alert": "OFF",
            "manual_mode": "OFF",
            "esp_error": str(e),
        }


def send_esp_command(cmd: str) -> Dict[str, Any]:
    r = requests.get(
        f"{ESP_BASE}/command",
        params={"cmd": cmd},
        timeout=REQUEST_TIMEOUT,
    )
    r.raise_for_status()
    return r.json()


def append_history_row(data: Dict[str, Any], event_name: str) -> Dict[str, Any]:
    items = load_history()
    row = {
        "datetime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "event": event_name,
        "temp": data.get("temp", "--"),
        "hum": data.get("hum", "--"),
        "soil": data.get("soil", "--"),
        "pump": data.get("pump", "OFF"),
        "flow": data.get("flow", "0.00"),
        "cycle_ml": data.get("cycle_ml", "0.00"),
        "total_ml": data.get("total_ml", "0.00"),
        "auto_threshold": data.get("auto_threshold", "OFF"),
        "soil_dry_alert": data.get("soil_dry_alert", "OFF"),
        "no_water_alert": data.get("no_water_alert", "OFF"),
    }
    items.append(row)
    save_history(items)
    return row


@app.route("/")
def index():
    ensure_genesis_block()
    return render_template("index.html")


@app.route("/data")
def data():
    esp = get_esp_data()
    if not esp.get("esp_error"):
        append_history_row(esp, "READ_ALL")
        if esp.get("soil_dry_alert") == "ON":
            add_block({"event": "SOIL_DRY_ALERT", "snapshot": esp})
        if esp.get("no_water_alert") == "ON":
            add_block({"event": "NO_WATER_ALERT", "snapshot": esp})
    return jsonify(esp)


@app.route("/command", methods=["POST"])
def command():
    payload = request.get_json(silent=True) or {}
    cmd = str(payload.get("command", "")).strip()
    if not cmd:
        return jsonify({"ok": False, "message": "Thiếu command"}), 400
    try:
        esp_result = send_esp_command(cmd)
        current = get_esp_data()
        add_block(
            {
                "event": "COMMAND",
                "command": cmd,
                "result": esp_result,
                "snapshot": current,
            }
        )
        append_history_row(current, cmd)
        return jsonify(
            {
                "ok": True,
                "message": f"Đã gửi lệnh {cmd} tới ESP8266",
                "esp_result": esp_result,
            }
        )
    except Exception as e:
        return jsonify({"ok": False, "message": f"Lỗi gửi lệnh: {e}"}), 500


@app.route("/history")
def history():
    return jsonify(load_history())


@app.route("/blockchain")
def blockchain():
    ensure_genesis_block()
    chain = load_blockchain()
    return jsonify({"valid": validate_chain(chain), "chain": chain})


@app.route("/camera_info")
def camera_info():
    cam = get_camera()
    return jsonify(
        {
            "camera_url": "/video_feed",
            "camera_type": "usb_webcam",
            "camera_index": CAMERA_INDEX,
            "camera_ready": bool(cam is not None),
        }
    )


@app.route("/video_feed")
def video_feed():
    return Response(
        generate_camera_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )



@app.route("/voice", methods=["POST"])
def voice():
    payload = request.get_json(silent=True) or {}
    voice_text = str(payload.get("text", "")).strip().lower()

    if not voice_text:
        return jsonify(
            {
                "ok": False,
                "voice_text": "",
                "result": "Chưa nhận được nội dung giọng nói từ trình duyệt.",
            }
        )

    mapping = {
        "bật bơm": "PUMP_ON",
        "bat bom": "PUMP_ON",
        "tắt bơm": "PUMP_OFF",
        "tat bom": "PUMP_OFF",
        "đọc cảm biến": "READ_ALL",
        "doc cam bien": "READ_ALL",
        "tưới 20ml": "AUTO_WATER_20",
        "tuoi 20ml": "AUTO_WATER_20",
        "tưới 200ml": "AUTO_WATER_200",
        "tuoi 200ml": "AUTO_WATER_200",
        "bật tự động": "AUTO_THRESHOLD_ON",
        "bat tu dong": "AUTO_THRESHOLD_ON",
        "tắt tự động": "AUTO_THRESHOLD_OFF",
        "tat tu dong": "AUTO_THRESHOLD_OFF",
        "dừng tự động": "STOP_AUTO",
        "dung tu dong": "STOP_AUTO",
    }

    selected_command = None
    for key, value in mapping.items():
        if key in voice_text:
            selected_command = value
            break

    if selected_command:
        return jsonify(
            {
                "ok": True,
                "voice_text": voice_text,
                "command": selected_command,
                "result": f"Đã nhận lệnh giọng nói: {selected_command}",
            }
        )

    return jsonify(
        {
            "ok": True,
            "voice_text": voice_text,
            "result": "Đã nhận giọng nói nhưng chưa khớp lệnh điều khiển. Bạn có thể thử: bật bơm, tắt bơm, bật tự động, tưới 20mL.",
        }
    )



@app.route("/chat_api", methods=["POST"])
def chat_api():
    payload = request.get_json(silent=True) or {}
    raw_text = str(payload.get("message", "")).strip()
    text = raw_text.lower()

    mapping = {
        "bật bơm": "PUMP_ON",
        "bat bom": "PUMP_ON",
        "mở bơm": "PUMP_ON",
        "mo bom": "PUMP_ON",
        "tắt bơm": "PUMP_OFF",
        "tat bom": "PUMP_OFF",
        "đóng bơm": "PUMP_OFF",
        "dong bom": "PUMP_OFF",
        "đọc cảm biến": "READ_ALL",
        "doc cam bien": "READ_ALL",
        "kiểm tra cảm biến": "READ_ALL",
        "kiem tra cam bien": "READ_ALL",
        "tưới 20ml": "AUTO_WATER_20",
        "tuoi 20ml": "AUTO_WATER_20",
        "tưới 200ml": "AUTO_WATER_200",
        "tuoi 200ml": "AUTO_WATER_200",
        "bật tự động": "AUTO_THRESHOLD_ON",
        "bat tu dong": "AUTO_THRESHOLD_ON",
        "tắt tự động": "AUTO_THRESHOLD_OFF",
        "tat tu dong": "AUTO_THRESHOLD_OFF",
        "dừng tự động": "STOP_AUTO",
        "dung tu dong": "STOP_AUTO",
    }

    for key, value in mapping.items():
        if key in text:
            return jsonify(
                {
                    "ok": True,
                    "type": "command",
                    "command": value,
                    "reply": f"Tôi đã hiểu yêu cầu của bạn: {raw_text}. Hệ thống sẽ thực hiện lệnh {value}, sau đó mới lưu bằng chứng qua MetaMask.",
                    "quick_actions": [
                        {"label": "Bật bơm", "command": "PUMP_ON"},
                        {"label": "Tắt bơm", "command": "PUMP_OFF"},
                        {"label": "Đọc cảm biến", "command": "READ_ALL"},
                        {"label": "Trạng thái", "message": "Trạng thái hệ thống"},
                    ],
                }
            )

    if any(k in text for k in ["trạng thái", "trang thai", "tình hình", "tinh hinh", "hệ thống", "he thong"]):
        data = get_esp_data()
        reply = (
            f"Đây là tình trạng hiện tại của trang trại:\\n"
            f"- Nhiệt độ: {data.get('temp')} °C\\n"
            f"- Độ ẩm không khí: {data.get('hum')} %\\n"
            f"- Độ ẩm đất: {data.get('soil')}\\n"
            f"- Lưu lượng nước: {data.get('flow')} L/min\\n"
            f"- Bơm: {data.get('pump')}\\n"
            f"- Tự động theo ngưỡng: {data.get('auto_threshold')}\\n"
            f"- Đất khô: {data.get('soil_dry_alert')}\\n"
            f"- Không có nước: {data.get('no_water_alert')}"
        )
        return jsonify(
            {
                "ok": True,
                "type": "status",
                "refresh": True,
                "reply": reply,
                "quick_actions": [
                    {"label": "Đọc cảm biến", "command": "READ_ALL"},
                    {"label": "Giải thích cảnh báo", "message": "Giải thích cảnh báo"},
                    {"label": "Bật tự động", "command": "AUTO_THRESHOLD_ON"},
                ],
            }
        )

    if "giải thích cảnh báo" in text or "giai thich canh bao" in text or "cảnh báo" in text or "canh bao" in text:
        data = get_esp_data()
        messages = []
        if data.get("soil_dry_alert") == "ON":
            messages.append("Đất đang khô. Bạn nên tưới 20mL, tưới 200mL hoặc bật tự động.")
        if data.get("no_water_alert") == "ON":
            messages.append("Bơm đang không phát hiện nước. Hãy kiểm tra bồn chứa, ống dẫn và cảm biến lưu lượng.")
        if not messages:
            messages.append("Hiện tại chưa có cảnh báo nghiêm trọng. Hệ thống đang ở trạng thái ổn định.")
        return jsonify(
            {
                "ok": True,
                "type": "advice",
                "reply": "\\n".join(messages),
                "quick_actions": [
                    {"label": "Tưới 20mL", "command": "AUTO_WATER_20"},
                    {"label": "Tưới 200mL", "command": "AUTO_WATER_200"},
                    {"label": "Bật tự động", "command": "AUTO_THRESHOLD_ON"},
                ],
            }
        )

    return jsonify(
        {
            "ok": True,
            "type": "help",
            "reply": (
                "Tôi là trợ lý ảo nông trại. Tôi có thể giúp bạn điều khiển bơm, đọc cảm biến, "
                "kiểm tra tình trạng hệ thống và giải thích cảnh báo.\\n\\n"
                "Bạn có thể thử các câu như:\\n"
                "- Bật bơm\\n"
                "- Tắt bơm\\n"
                "- Đọc cảm biến\\n"
                "- Tưới 20mL\\n"
                "- Tưới 200mL\\n"
                "- Bật tự động\\n"
                "- Trạng thái hệ thống"
            ),
            "quick_actions": [
                {"label": "Bật bơm", "command": "PUMP_ON"},
                {"label": "Tắt bơm", "command": "PUMP_OFF"},
                {"label": "Đọc cảm biến", "command": "READ_ALL"},
                {"label": "Trạng thái", "message": "Trạng thái hệ thống"},
                {"label": "Giải thích cảnh báo", "message": "Giải thích cảnh báo"},
            ],
        }
    )


@app.route("/export_blockchain_excel")
def export_blockchain_excel():
    try:
        import pandas as pd
    except Exception:
        return jsonify({"ok": False, "message": "Thiếu pandas/openpyxl để xuất Excel"}), 500

    chain = load_blockchain()
    rows: List[Dict[str, Any]] = []
    for block in chain:
        rows.append(
            {
                "index": block.get("index"),
                "timestamp": block.get("timestamp"),
                "prev_hash": block.get("prev_hash"),
                "hash": block.get("hash"),
                "data": json.dumps(block.get("data", {}), ensure_ascii=False),
            }
        )

    df = pd.DataFrame(rows)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="blockchain", index=False)
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="blockchain.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


if __name__ == "__main__":
    ensure_genesis_block()
    print(f"Flask dang proxy toi ESP8266: {ESP_BASE}")
    app.run(host="0.0.0.0", port=5000, debug=True)
